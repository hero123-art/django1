from django.shortcuts import render, redirect
from django.contrib import messages
# Create your views here.
def reader(request):
    if request.user.is_authenticated:
        return render(request, 'categories.html')
    
    else:
        messages.info(request, 'please login to continue')
        return redirect('login')
    
def comment(request):
    
    return render(request, 'comment.html')
