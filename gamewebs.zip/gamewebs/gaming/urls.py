from django.urls import path

from . import views

urlpatterns = [
    path('games', views.games, name="games"),
    path('gamee', views.gamee, name="gamee"),
    path('thankyou', views.thankyou, name="thankyou"),
    path('order', views.order, name="order"),
    path('rewiew', views.rewiew, name="rewiew"),
    path('about', views.about, name="about"),
] 

