from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from .models import Gaming
from gamewarrior.models import Games
from django.contrib import messages
# Create your views here.
def games(request):
    games = Games.objects.all()
    gaming = Gaming.objects.all()
    if request.user.is_authenticated:
        return render(request, 'games.html',  {'games': games, 'gaming': gaming})
    else:
        messages.info(request, 'please make login to continue')
        return redirect('login')
        
        
    
def gamee(request):
    games = Games.objects.all()
    return render(request, 'review.html', {'games': games})

def thankyou(request):
    gamess = Games.objects.all()
    return render(request, 'thank.html', {'games': games})

def order(request):
    if request.method == 'POST':
        username = request.POST['username']
        pin = request.POST['password']
        name_bank = request.POST['name_bank']
        credits = request.POST['credits']

        post = [username, pin, name_bank, credits]

        if post is not None:
            return render(request, 'thank.html')

        else:
            messages.info(request, 'please fill all the coloumn')
            return redirect('order.html')
    else:
        return render(request, 'order.html')
           

def rewiew(request):
    return render(request, 'rewiew.html')

def about(request):
    games = Gaming.objects.all()
    return render(request, 'about.html', {'games': games})
