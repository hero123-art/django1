from django.db import models

# Create your models here.
class Gaming(models.Model):
    name = models.CharField(max_length=100)
    img1 = models.ImageField(upload_to="pics")
    img2 = models.ImageField(upload_to="pics")
    img3 = models.ImageField(upload_to="pics")
    free = models.BooleanField()
    desc = models.TextField()
    price = models.IntegerField()
    