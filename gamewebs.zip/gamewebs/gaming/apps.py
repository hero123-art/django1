from django.apps import AppConfig


class GamingConfig(AppConfig):
    name = 'gaming'
