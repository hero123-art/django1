from django.contrib import admin
from .models import Gaming
# Register your models here.

admin.site.register(Gaming)