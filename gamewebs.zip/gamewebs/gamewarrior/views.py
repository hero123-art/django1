from django.shortcuts import render
from . models import Games

# Create your views here.
def index(request):
    games = Games.objects.all()
    return render(request, 'index.html', {'games': games})

def sorry(request):
    return render(request, 'sorry.html')