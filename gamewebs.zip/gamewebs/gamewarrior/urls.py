from django.urls import path

from gamewarrior import views

urlpatterns = [
    path('', views.index, name="index"),
    path('sorry', views.sorry, name="sorry"),
] 

