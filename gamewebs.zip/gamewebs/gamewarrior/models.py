from django.db import models
import time
# Create your models here.
class Games(models.Model):
    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    desc = models.TextField()
    GB = models.IntegerField()
    time = models.TextField()
    price = models.IntegerField()
    free = models.BooleanField()
