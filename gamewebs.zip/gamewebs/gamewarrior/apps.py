from django.apps import AppConfig


class GamewarriorConfig(AppConfig):
    name = 'gamewarrior'
